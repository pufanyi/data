#include <conio.h>
#include <windows.h>
#include <ctime>
#include <cstdio>
#include <iostream>

using namespace std;

/*******************************************************************************
 * ��ȡ����̨��ǰ�����С
 ******************************************************************************/
COORD get_font_size()
{
    COORD font_size;
    HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
    /* ������Ϣ */
    struct CONSOLE_FONT
    {
        DWORD index;
        COORD dim;
    } cfi;
    typedef COORD (WINAPI *PROCGETCONSOLEFONTSIZE)(HANDLE, DWORD);
    typedef BOOL (WINAPI *PROCGETCURRENTCONSOLEFONT)(HANDLE, BOOL, struct CONSOLE_FONT*);

    HMODULE hKernel32 = GetModuleHandle("kernel32");
    PROCGETCONSOLEFONTSIZE GetConsoleFontSize = (PROCGETCONSOLEFONTSIZE)GetProcAddress(hKernel32,"GetConsoleFontSize");
    PROCGETCURRENTCONSOLEFONT GetCurrentConsoleFont = (PROCGETCURRENTCONSOLEFONT)GetProcAddress(hKernel32,"GetCurrentConsoleFont");

    GetCurrentConsoleFont(handle, FALSE, &cfi);             /* ��ȡ��ǰ����������Ϣ */
    font_size = GetConsoleFontSize(handle, cfi.index);      /* ��ȡ��ǰ���������Ϣ[�ַ����ȼ��߶���ռ������] */

    return font_size;
}

/*******************************************************************************
 * ���չʾ����̨����
 ******************************************************************************/
void FullScreen()
{
    HWND hwnd = GetForegroundWindow();
    HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);   /* ��׼������������ */
    int cx = GetSystemMetrics(SM_CXSCREEN);            /* ��Ļ���� */
    int cy = GetSystemMetrics(SM_CYSCREEN);            /* ��Ļ�߶� */

    COORD size = get_font_size();
    char cmd[32] = { 0 };
    sprintf(cmd, "MODE CON: COLS=%d LINES=%d", cx / size.X, cy / size.Y);
    system(cmd);
    SetWindowPos(hwnd, HWND_TOP, 0, 0, cx, cy, 0);
}

void changecolor()
{
    char a[100];
    sprintf(a, "color %x%x", rand()%16, rand()%16);
    system(a);
}

void HideCursor()
{
    CONSOLE_CURSOR_INFO cursor_info = {1, 0};
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info);
}

enum fy
{
    _d6 = 212,
    d1 = 262, d1_ = 277, d2 = 294, d2_ = 311, d3 = 330, d4 = 349, d5 = 392, d5_ = 415, d6 = 440, d6_ = 466, d7 = 494,
    z1 = 523, z1_ = 554, z2 = 578, z2_ = 622, z3 = 659, z4 = 698, z4_ = 740, z5 = 784, z5_ = 831, z6 = 880, z6_ = 932, z7 = 988,
    g1 = 1046, g1_ = 1109, g2 = 1175, g2_ = 1245, g3 = 1318, g3_ = 1345, g4 = 1397, g4_ = 1480,
    g5 = 1568, g5_ = 1661, g6 = 1760, g6_ = 1865, g7 = 1976, yaya = 0
};

struct yf
{
    enum fy s;
    int t;
};

void huluwa()
{
    struct yf a[1000] =
    {
        {z1, 100}, {d6, 100}, {d5, 50}, {d6, 50}, {yaya, 100},
        {z1, 50}, {d6, 50}, {d5, 50}, {z1, 50}, {d6, 100}, {yaya, 50}, {z1, 50},
        {d6, 50}, {d6, 100}, {d5, 100}, {yaya, 50}, {d6, 50},
        {z1, 50}, {d6, 100}, {d5, 50}, {z1, 50}, {d6, 100}, {yaya, 100},
        {d1, 100}, {d1, 100}, {d3, 200},
        {d1, 50}, {d1, 100}, {d3, 150}, {yaya, 100},
        {d6, 100}, {d6, 100}, {d6, 50}, {d5, 50}, {d6, 100},
        {d5, 50}, {d1, 100}, {d3, 150}, {yaya, 100},
        {z1, 50}, {d6, 50}, {d6, 50}, {d5, 50}, {d6, 200},
        {d5, 50}, {d1, 100}, {d2, 150}, {yaya, 100},
        {d7, 200}, {d7, 50}, {d5, 50}, {d3, 100},
        {d5, 400},
        {z1, 50}, {yaya, 50}, {d6, 75}, {d6, 25}, {d5, 75}, {d5, 25}, {d6, 75}, {d6, 25},
        {yaya, 50}, {d5, 100}, {d1, 50}, {d3, 100}, {yaya, 100},
        {z1, 50}, {yaya, 50}, {d6, 75}, {d6, 25}, {d5, 75}, {d5, 25}, {d6, 75}, {d6, 25},
        {yaya, 50}, {d5, 100}, {d1, 50}, {d2, 100}, {yaya, 100},
        {d3, 200}, {d3, 50}, {d1, 50}, {_d6, 100},
        {d1, 400},
        {d3, 50}, {d5, 100}, {d6, 50}, {d6, 200},
        {d3, 50}, {d5, 100}, {d6, 50}, {d6, 200},
        {z1, 200}, {yaya, 50}, {d7, 50}, {d5, 50},
        {d6, 400},
        {z1, 100}, {d6, 100}, {d5, 50}, {d6, 50}, {yaya, 100},
        {z1, 50}, {d6, 50}, {d5, 50}, {z1, 50}, {d6, 100}, {yaya, 50}, {z1, 50},
        {d6, 50}, {d6, 100}, {d5, 100}, {yaya, 50}, {d6, 50},
        {z1, 50}, {d6, 100}, {d5, 50}, {z1, 50}, {d6, 100}, {yaya, 100},
        {d1, 100}, {d1, 100}, {d3, 200},
        {d1, 50}, {d1, 100}, {d3, 150}, {yaya, 100},
        {d6, 100}, {d6, 100}, {d6, 50}, {d5, 50}, {d6, 100},
        {d5, 50}, {d1, 100}, {d3, 150}, {yaya, 100},
        {z1, 50}, {d6, 50}, {d6, 50}, {d5, 50}, {d6, 200},
        {d5, 50}, {d1, 100}, {d2, 150}, {yaya, 100},
        {d7, 200}, {d7, 50}, {d5, 50}, {d3, 100},
        {d5, 400},
        {z1, 50}, {yaya, 50}, {d6, 75}, {d6, 25}, {d5, 75}, {d5, 25}, {d6, 75}, {d6, 25},
        {yaya, 50}, {d5, 100}, {d1, 50}, {d3, 100}, {yaya, 100},
        {z1, 50}, {yaya, 50}, {d6, 75}, {d6, 25}, {d5, 75}, {d5, 25}, {d6, 75}, {d6, 25},
        {yaya, 50}, {d5, 100}, {d1, 50}, {d2, 100}, {yaya, 100},
        {d3, 200}, {d3, 50}, {d1, 50}, {_d6, 100},
        {d1, 400},
        {d3, 50}, {d5, 100}, {d6, 50}, {d6, 200},
        {d3, 50}, {d5, 100}, {d6, 50}, {d6, 200},
        {z1, 200}, {yaya, 50}, {d7, 50}, {d5, 50},
        {d6, 400},
        {yaya, 100}, {yaya, 100}, {yaya, 100}, {yaya, 100},
        {yaya, 100}, {yaya, 100}, {yaya, 100}, {yaya, 100},
    };
    struct yf * atop;
    atop = a;
    int n = 200;
    while(n--)
    {
        Beep(atop->s, atop->t*5);
        atop++;
    }
}

DWORD WINAPI Fun(LPVOID lpParamter)
{
    for( ; ; )
        huluwa();
}

int main()
{
    FullScreen();
    HideCursor();
    system("color 00");
    srand((unsigned)time(NULL));
    int i = 0;
    HANDLE hThread = CreateThread(NULL, 0, Fun, NULL, 0, NULL);
    CloseHandle(hThread);
    for(;;)
    {
        i %= 200;
        if(!i) changecolor();
        i++;
        printf("Ҧ����̫ǿ��������");
		Sleep(20);
    }
    return 0;
}
